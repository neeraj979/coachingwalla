/*------------------partners list swiper------------------------*/
var swiper = new Swiper(".partners-img", {
    slidesPerView: 5,
    spaceBetween: 30,
    loop: true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    breakpoints:{
      360:{
        slidesPerView: 1,
      },
      800:{
        slidesPerView: 3,
      },
      1040:{
        slidesPerView: 3,
      },
    },
  });
  
 
/*--------------------------cursor animation----------------------------------*/
   
  var cursor = document.getElementById("cursor");
  var timeout;
  document.addEventListener('mousemove', function(e){
      let x = e.pageX;
      let y = e.pageY;
      cursor.style.top = y + "px";
      cursor.style.left = x + "px";
  });
  
  var a =  document.querySelectorAll('.child');
      a.forEach(function(elm){
          elm.addEventListener('mouseenter', function(){
              cursor.style.transform= "scale(1)";
              cursor.style.transition= "0.8s";
              cursor.style.transform= "translate(-50%, -50%)";
      });
  });
    
  a.forEach(function(elm){
      elm.addEventListener('mouseleave', function(){
          cursor.style.transform= "scale(0)";
          cursor.style.transition= "0.8s";
          
  });
  });
/*------------------goal counter---------------------*/
let goalring = document.querySelectorAll(".goal-ring");
goalcount = document.querySelectorAll(".goal-count");

let goalcountstart = 0,
goalcountend= 90,
speed = 15;

let progress = setInterval(() => {
goalcountstart++;
for(var i=0; i<goalcount.length; i++){
goalcount[i].textcontent = `${goalcountstart}%`
}
for(var j=0; j<goalring.length; j++){
goalring[0].style.background = `conic-gradient(hsl(0, 0%, 100%) ${goalcountstart*3.4}deg, transparent 0deg)`
goalring[1].style.background = `conic-gradient(hsl(0, 0%, 100%) ${goalcountstart*3.2}deg, transparent 0deg)`
goalring[2].style.background = `conic-gradient(hsl(0, 0%, 100%) ${goalcountstart*3}deg, transparent 0deg)`
}
if(goalcountstart == goalcountend){
  clearInterval(progress);
}
},speed);

/*-------small screen js for menu bar------*/
var headertext = document.getElementsByClassName("small-header");
var bar = document.getElementById("bar");
var newitem = document.getElementsByClassName("menu-item");
bar.addEventListener('click', function(){
for(var i=0; i<newitem.length; i++){
newitem[i].classList.toggle("newmenu");
}
for(var j=0; j<headertext.length; j++){
headertext[j].style.transition = "0.5s";
headertext[j].classList.toggle("newheader");
}
});